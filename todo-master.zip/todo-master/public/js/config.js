/**
 * Created by lzw on 14-8-21.
 */
var appId='ozewwcwsyq92g2hommuxqrqzg6847wgl8dtrac6suxzko333';
var appKey='ni0kwg7h8hwtz6a7dw9ipr7ayk989zo5y8t0sn5gjiel6uav';
