<?php

class users 
{
	protected static $table_name = "users";
	public $id;
	public $username;
		
	private function has_attribute($attribute)
	{
		$object_vars = $this->attributes();
		
		return array_key_exists($attribute, $object_vars);
	}
	
	protected function attributes()
	{
		return get_object_vars($this);
	}
	
	private static function instantiate($record)
	{
		$object = new self;
		
		foreach($record as $attribute => $value)
		{
			if($object->has_attribute($attribute))
			{
				$object->$attribute = $value;
			}
		}
		return $object;
	}
	
	public function get_users()
	{
		global $db;
		
		$attributes = $this->attributes();
		
		$sql = "SELECT ";
		$sql .= join(", ", array_keys($attributes));
		$sql .= " FROM " . self::$table_name;
			
		$records = self::find_by_sql($sql);
		
		return $records;
	}
	
	public function create_user()
	{
		global $db;
		
		$sql = "INSERT INTO " . self::$table_name . " (";
	}
	
	public function update_user()
	{
	
	}
	
	public function delete_user()
	{
	
	}
	
	public static function find_by_id($id = 0)
	{
		global $db;
		
		$result_array = self::find_by_sql("SELECT * FROM " . self::$table_name . " WHERE id = {$id} LIMIT 1");
		
		return !empty($result_array) ? array_shift($result_array) : false;
	}
	
	public static function find_by_sql($sql = "")
	{
		global $db;
		
		$result_set = $db->query($sql);
		$object_array = array();
		
		while($row = $db->fetch_data($result_set))
		{
			$object_array[] = self::instantiate($row);
		}
		return $object_array;
	}
}

$users = new users;

?>