<?php

	/**
	* Here to give us info on the shizzle that doesn't always work
	*/
	class debug
	{
		public static $error_message;
		
		public function output_error($message)
		{
			return json_encode($message);
		}
	}
	

?>