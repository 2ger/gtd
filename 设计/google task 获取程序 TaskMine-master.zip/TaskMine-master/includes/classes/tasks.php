<?php

/**
* MyTask Class
* 
* Instantiate the database in index
* Make a call to the global instance of the database for performing the CRUD actions (Create Read Update Delete)
* 
* 
*/

class MyTask 
{
	protected static $table_name = "task_list";
	public $id;
	public $task_name;
	public $task_notes;
	public $date_updated;
	public $priority;
	public $user_id;
	
	private function has_attribute($attribute)
	{
		$object_vars = $this->attributes();
		
		return array_key_exists($attribute, $object_vars);
	}
	
	protected function attributes()
	{
		return get_object_vars($this);
	}
	
	private static function instantiate($record)
	{
		$object = new self;
		
		foreach($record as $attribute => $value)
		{
			if($object->has_attribute($attribute))
			{
				$object->$attribute = $value;
			}
		}
		return $object;
	}
	
	public static function find_by_sql($sql = "")
	{
		global $db;
		
		$result_set = $db->query($sql);
		$object_array = array();
		
		while($row = $db->fetch_data($result_set))
		{
			$object_array[] = self::instantiate($row);
		}
		return $object_array;
	}
	
	public function find_by_id($id = 0)
	{
		global $db;
		
		$attributes = $this->attributes();
		
		$sql = sprintf("SELECT %s FROM %s WHERE id = %s LIMIT 1",
			join(", ", array_keys($attributes)), self::$table_name, $id);
		
		$result_array = self::find_by_sql($sql);
		
		return !empty($result_array) ? array_shift($result_array) : false;
	}
	
	public function create_task($name = "", $text = "")
	{
		global $db;
		
		$name = strip_tags($name);
		$text = strip_tags($text);
		
		$sql = sprintf("INSERT INTO %s
			(task_name, 
			task_notes,
			date_updated)
			VALUES ('%s','%s', now())", self::$table_name, $name, $text);
			
		return $db->query($sql);
	}
	
	public function get_latest_task_id()
	{
		global $db;
		
		return $db->last_insert();
	}

	public function update_task($id, $name = "", $text = "", $priority)
	{
		global $db;
		
		$sql = sprintf("UPDATE %s SET 
			task_name = '%s',
			task_notes = '%s',
			date_updated = now(),
			priority = '%d'
			WHERE id = '%d'", self::$table_name, $name, $text, $priority, $id);
		
		$db->query($sql);
	}
	
	public function update_list($update_array)
	{
		global $db;
		
		$field_list = array("id", "title", "updated", "selflink", "position", "notes", "status", "due", "links");
		
		foreach ($update_array as $task_item)
		{
			$sql .= "INSERT INTO " . self::$table_name; 
			$sql .= " (" . join(", ", $field_list ) . ") ";
			$sql .= "VALUES( " . join(", ", $update_array ) . ") ";
			
			$sql .= "\n\r";
			//$db->query($sql);
							
		}
		return $sql;
	}
	
	public function get_list()
	{
		global $db;
		
		$attributes = $this->attributes();
		
		$sql = "SELECT ";
		$sql .= join(", ", array_keys($attributes));
		$sql .= " FROM " . self::$table_name;
		$sql .= " ORDER BY priority ASC";
			
		$list = self::find_by_sql($sql);
		
		return $list;
	}
	
	public function get_list_by_field_name($field = "id")
	{
		global $db;

		$attributes = $this->attributes();

		$sql = "SELECT ";
		$sql .= "id, ";
		$sql .= "task_name, ";
		$sql .= "priority";
		$sql .= " FROM " . self::$table_name;
		$sql .= " ORDER BY priority ASC";
		
		$list = self::find_by_sql($sql);
		
		return $list;
	}
}

$task = new MyTask();

?>