<?php
/**
* Connections
*/


class database
{
	private $connection;
	
	function __construct($database_name)
	{
		$this->open_connection($database_name);
	}
	
	public function open_connection($database_name)
	{
		$this->connection = mysql_connect("127.0.0.1", USERNAME, PASSWORD);
		
		if(!$this->connection)
		{
			die("Unable to connect to database server: " . SERVER . ". Error: " . mysql_error());
		}
		
		if(!$database_name)
		{
			die("Error: No database Set");
		}
		else
		{
			$database_selection = mysql_select_db($database_name, $this->connection);
			
			if(!$database_selection)
			{
				die("Unable to select database: " . $database_name . ": " . mysql_error());
			}
		}
	}
	
	public function query($sql)
	{
		$run = mysql_query($sql, $this->connection);
		
		$this->confirm_query($run);
		
		return $run;
	}
	
	public function fetch_data($fetch, $array_type = 'array')
	{
		if($array_type == 'array')
		{
			$data = mysql_fetch_array($fetch);
		}
		elseif($array_type == 'assoc')
		{
			$data = mysql_fetch_assoc($fetch);
		}
		
		return $data;
	}
	
	public function mysql_prep($value)
	{
		$magic_quotes_active = get_magic_quotes_gpc();
	
		$new_enough_php = function_exists("mysql_real_escape_string");
		
		if($new_enough_php)
		{
			if($magic_quotes_active)
			{
				$value = stripslashes($value);
			}
			
			$value = mysql_real_escape_string($value);
		}
		else
		{
			if(!$magic_quotes_active)
			{
				$value = addslashes($value);
			}
		}
		
		return $value;
	}	

	public function last_insert()
	{
		$result = mysql_insert_id();
		
		return $result;
	}

	private function confirm_query($results)
	{
		if(!$results)
		{
			die("Unable to execute query. Error: " . mysql_error());
		}
	}
}

$db = new database("tasks");

?>