$(function() 
{
	$("#sortable, #alsosortable").sortable({
	    connectWith: '.connected',
	    receive: function(event,ui) { adopt(this); }
	   /* remove: function(event,ui) { orphan(this); } */
	  });
});

$('#addTask').live('click',function()
{
	$.post("get_task.php", { new_task: 1 }, 
	function(data){
		$("#alsosortable").append('<li class="list_item">\
			<div class="text_div">\
				<textarea name="' + data + '" class="textspace ' + data + '">\
New Task\
				</textarea>\
			</div>\
			<div class="expand_close">\
				<span onClick="return openTask(' + data + ');">Open/Close</span>\
			</div>\
		</li>');
	 });			
});
	
function adopt(which) 
{	
	if ($(which).hasClass('empty')) 
	{
		$(which).removeClass('empty').find('.empty').remove();		
	}		
}

function updateList() 
{		
	$.post("index.php", { "update_list": 1 },
 	function(data)
	{					
			$('#updateArea').hide().fadeIn(3000).html(data);
 	});
}

function updateOne(option)
{
	$("." + option).change(function() {
    	// save the field's new value
    	$.post("save_data.php", { field: $(this).attr('id'), value: $(this).val() });
    	}
	);
}

$(document).ready(
	function() 
	{
		$('div.expand_close').live("click",
		function()
		{

			var id = $(this).attr('id');
		
			$.post("get_task.php", { "open_one": id },
		 	function(data)
			{					
					$('#updateArea').hide().fadeIn(3000).html(data);
					
				/*for(var key in data)
				{ 
					var keyClass = key;
					var value = data[key];
					
					switch(keyClass)
					{
						case 'username':
							$('.' + keyClass).val(value);
							break;
						default:
							$('.' + keyClass).html(value);
					}
				} */
		 	}); 
		});
	});