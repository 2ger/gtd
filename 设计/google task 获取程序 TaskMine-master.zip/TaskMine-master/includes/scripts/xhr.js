window.onload = initAll;

var xhr = false;

function initAll () {
	document.getElementById("makeTextRequest").onclick = getNewFile;
}

function getNewFile () {
	makeRequest(this.href);
	
	return false;
}

function makeRequest (url) {
	if(window.XMLHttpRequest)
	{
		xhr = new XMLHttpRequest();
	}
	
	if(xhr)
	{		
		xhr.onreadystatechange = showContent;
		xhr.open("GET", url, true);
		xhr.send(null);
	}
	else
	{
		document.getElementById("updateArea").innerHTML = "Sorry, bad request.";
	}
}

function showContent () {
	if(xhr.readyState == 4)
	{
		if(xhr.status == 200)
		{
			var outMsg = xhr.responseText;
		}
		else
		{
			var outMsg = "There was a problem with the request.";
		}
		
		return outMsg;
	}
}