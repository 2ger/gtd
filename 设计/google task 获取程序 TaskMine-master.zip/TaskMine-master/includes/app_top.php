<?php

    require_once("configuration/config.php"); // Set the connection constants
    require_once("classes/database_connection.php");
	require_once('classes/users.php');
	require_once('classes/tasks.php');

?>