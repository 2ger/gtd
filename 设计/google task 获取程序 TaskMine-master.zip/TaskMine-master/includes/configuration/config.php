<?php
/*
 *
 *
 */
date_default_timezone_set("Europe/London");

define("SERVER", "127.0.0.1");
define("USERNAME", "paulhopgood");
define("PASSWORD", "99greens");

?>