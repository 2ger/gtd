<li class="list_item">
	<div class="text_div">
<?php echo $taskdetails['title'] ; ?>
	</div>
	<div class="expand_close" id="<?php echo $taskdetails['id']; ?>">
		Open/Close
	</div>
</li>