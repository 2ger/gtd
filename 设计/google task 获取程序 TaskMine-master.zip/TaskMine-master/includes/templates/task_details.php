<div>
	<span class="task_name"></span><br />
	<hr class="header_rule"></hr>
	<span>Date updated: </span><span class="date_updated"></span><br /><br />
	<span>Asignee: </span><input type="text" class="username" value=""><br />
	<textarea name="Name" rows="40" cols="70" class="task_notes">
	</textarea>
</div>