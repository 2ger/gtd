<script src="../scripts/jquery-ui-1.8.9.custom/js/jquery-1.4.4.min.js" type="text/javascript"></script>
<script src="../scripts/jquery-ui-1.8.9.custom/js/jquery-ui-1.8.9.custom.min.js" type="text/javascript"></script>
<script src="../scripts/list_functions.js" type="text/javascript"></script>

<?php

require_once('../app_top.php');

 $people = $users->get_users();	

echo "<pre>";
print_r($people);
echo "</pre>";

echo "This is an object: " , json_encode($people);
// echo "<br />";
// echo json_encode(array("name"=>"John","time"=>"2pm"));

?>
<input type="button" name="button" value="click it" id="button">

<div class="something">
	
</div>