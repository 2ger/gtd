<div>
	<select>
<?php	

foreach($people as $person)
{
	$name = get_object_vars($person);
	
	$selected = ($name['id'] == $task['user_id']) ? "selected='selected'" : "";
	
	echo "<option value='" . $name['id'] . "' " . $selected . ">" 
	. $name['username'] . "</option><br />";
}

?>
	</select>
</div>