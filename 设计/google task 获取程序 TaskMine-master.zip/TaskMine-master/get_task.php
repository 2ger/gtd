<?php

require_once('includes/app_top.php');

$new_task 		= (isset($_POST['new_task'])) ? $_POST['new_task'] : null;
$update_task 	= (isset($_POST['update_task'])) ? $_POST['update_task'] : null;
$open_one 		= (isset($_POST['open_one'])) ? $_POST['open_one'] : null;
$update_list	= (isset($_POST['update_list'])) ? $_POST['update_list'] : null;
	

if($new_task)
{
	$task->create_task();
	$result = $task->get_latest_task_id();
	
	echo $result;
}

if($update_task)
{
	
	$size_of_update = sizeof($update_task);
	
	for($i = 0; $i < $size_of_update; $i++)
	{
		$task->update_task($update_task[$i]['name'], '', $update_task[$i]['value'], $i);
		
	}
		
	echo "<span style='font-family: Helvetica; font-size:14px;'>Updated</span>";	
}


if($open_one) 
{	
//	$oneTask = new Task();
	echo $taskdetails['notes'];
}

// if($task) 
// {
// 	// $people = $users->get_users();
// 	// $list = $task->get_list("priority");
// 	
// 	// echo json_encode($list);
// 
// }

?>