<?php
require_once("includes/app_top.php");

session_start();
require_once 'includes/google-api/src/apiClient.php';
require_once 'includes/google-api/src/contrib/apiTasksService.php';

$client = new apiClient();
// Visit https://code.google.com/apis/console to generate your
// oauth2_client_id, oauth2_client_secret, and to register your oauth2_redirect_uri.
// $client->setClientId('insert_your_oauth2_client_id');
// $client->setClientSecret('insert_your_oauth2_client_secret');
// $client->setRedirectUri('insert_your_oauth2_redirect_uri');
// $client->setApplicationName("Tasks_Example_App");
$tasksService = new apiTasksService($client);



if (isset($_REQUEST['logout'])) {
  unset($_SESSION['access_token']);
}

if (isset($_SESSION['access_token'])) {
  $client->setAccessToken($_SESSION['access_token']);
} else {
  $client->setAccessToken($client->authenticate());
  $_SESSION['access_token'] = $client->getAccessToken();
}

if (isset($_GET['code'])) {
  header('Location: http://' . $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF']);
}

$update_list	= (isset($_POST['update_list'])) ? $_POST['update_list'] : null;


if($update_list)
{
	
	$lists = $tasksService->tasklists->listTasklists();
	foreach ($lists['items'] as $list) 
	{
	  	// print "<h3 id='{$list['id']}'>{$list['title']}</h3>";
	  	$tasks = $tasksService->tasks->listTasks($list['id']);
	  	
		foreach ($tasks['items'] as $taskdetails) 
		{
	  		$update = $task->update_list($taskdetails);
		}
	}
	
	echo $update;
		
	//echo "<span style='font-family: Helvetica; font-size:14px;'>Updated</span>";	
}

?>
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-type" content="text/html; charset=utf-8">
	
	<title>Task List</title>
	
	<link rel="stylesheet" href="includes/scripts/jquery-ui-1.8.9.custom/css/ui-lightness/jquery-ui-1.8.9.custom.css" type="text/css" media="all" />
	<link rel="stylesheet" type="text/css" href="includes/styles/static_header.css" />
	<link rel="stylesheet" type="text/css" href="includes/styles/task_list.css" />
	
	<script src="includes/scripts/jquery-ui-1.8.9.custom/js/jquery-1.4.4.min.js" type="text/javascript"></script>
	<script src="includes/scripts/jquery-ui-1.8.9.custom/js/jquery-ui-1.8.9.custom.min.js" type="text/javascript"></script>
	<script src="includes/scripts/list_functions.js" type="text/javascript"></script>

</head>
<body>

<div id="top_bar_height">
	<div id="top_bar">
			<a id="addTask" href="#">Add Task</a>
			<input type="button" value="Update list" id="updateList" onClick="return updateList();">
			<span id="updateArea">&nbsp;</span>
	</div>
</div>
	
<ul id="alsosortable" class="connected">
	<input type="hidden" id="id" value="1">
</ul>
	<br/>

	<div class="main_list">
		<ul id="sortable" class="connected ui-helper-reset">
<?php

  		//$oneTask = new Task();
$lists = $tasksService->tasklists->listTasklists();
foreach ($lists['items'] as $list) {
  print "<h3 id='{$list['id']}'>{$list['title']}</h3>";
  $tasks = $tasksService->tasks->listTasks($list['id']);
  	foreach ($tasks['items'] as $taskdetails) {
  	
  	echo "<pre>"; 
  	print_r($taskdetails);
  	echo "</pre>";
  	//$notes = $oneTask->getNotes($tasks['id']);
  		include('includes/templates/list.php');
	}
}

?>		
		</ul>
	</div>
<?php


include('includes/templates/task_details.php');

?>
<?php $_SESSION['access_token'] = $client->getAccessToken(); ?>
</body>	
</html>